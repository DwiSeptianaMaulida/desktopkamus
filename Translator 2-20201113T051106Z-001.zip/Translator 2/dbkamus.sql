-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Des 2019 pada 00.18
-- Versi server: 10.4.10-MariaDB
-- Versi PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbkamus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `app_admin`
--

CREATE TABLE `app_admin` (
  `user_id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `tanggal_daftar` varchar(200) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `kontak` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `app_admin`
--

INSERT INTO `app_admin` (`user_id`, `nama`, `username`, `tanggal_daftar`, `email`, `password`, `kontak`, `description`) VALUES
(1202181910, 'Razky Febriansyah', 'razky', '07/11/2019 18:44:13', 'razky@gmail.com', 'razky', '082223736565', NULL),
(1202181914, 'Muhammad Firriezky', 'firriezky', '10/11/2019 09:06:49', 'firriezky@gmail.com', 'firriez', '082179973930', NULL),
(1202181915, 'Ahmad Syakir', 'ahmadsyakir', '11/11/2019 14:23:48', 'syakir@sisfo.co.id', 'syakir', '081345657689', NULL),
(1202181917, 'Novel Baswedan', 'novbaswedan', '12/11/2019 08:14:21', 'novbaswedan@kpk.go.id', 'savekpk', '082199849230', NULL),
(1202181918, 'Aprilia Mega P', 'apriliamegaps', '12/11/2019 17:36:28', 'shasaaprilia5@gmai.com', 'agata18', '0975442', NULL),
(1202181920, 'Hanif', 'mhzahran', '20/11/2019 11:39:43', 'jjjj@mmms.com', 'cobaajahaha', '888888', NULL),
(1202181921, 'Budi Setiawan', 'budisetiawan', '20/11/2019 19:48:05', 'budisetiawan@gmail.com', 'budisetiawan', '088223738709', NULL),
(1202181922, 'Muhammad Imron', 'imron', '21/11/2019 21:08:37', 'imron@gmail.com', 'imron', '088223738709', NULL),
(1202181923, 'Ikhsan Aziz', 'ikhsanaziz', '21/11/2019 21:14:43', 'ikhsanaziz@yahoo.com', 'bismillah', '0882344544454', NULL),
(1202181926, 'Sumarna', 'sumarna', '03/12/2019 05:59:55', 'sumarna@gmail.com', 'sumarna', '081279992332', NULL),
(1202181927, 'Admin Kopma', 'admin', '03/12/2019 06:08:38', 'admin@kopma.com', 'admin', '081278965467', NULL),
(1202181930, 'aprilia mega ', 'apriliamegaps2', '03/12/2019 07:43:23', 'shasaaprili5@gmai.com', 'agata18', '081450290519', NULL),
(1202181933, 'Febrian Abimanyu', 'itsfebry', '15/12/2019 09:09:23', 'itsfebry@gmail.com', '123456', '082287678990', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `queryistilah`
--

CREATE TABLE `queryistilah` (
  `Kategori` varchar(255) DEFAULT NULL,
  `Istilah` varchar(255) DEFAULT NULL,
  `Arti` varchar(255) DEFAULT NULL,
  `Unique` varchar(255) NOT NULL,
  `Unique2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `queryistilah`
--

INSERT INTO `queryistilah` (`Kategori`, `Istilah`, `Arti`, `Unique`, `Unique2`) VALUES
('Pertanian', 'Manure', 'Pupuk', 'ManurePertanianPupuk', 'PertanianManure'),
('Industri', 'PLTA', 'Pembangkit Listrik Tenaga Air', 'PLTAIndustriPembangkit Listrik Tenaga Air', 'IndustriPLTA'),
('Industri', 'PLTU', 'Pembangkit Listrik Tenaga Uap', 'PLTUIndustriPembangkit Listrik Tenaga Uap', 'IndustriPLTU'),
('Industri', 'Puddle', 'Lumpur', 'PuddleIndustriLumpur', 'IndustriPuddle'),
('Pertanian', 'Seeder', 'Alat Pembibitan', 'SeederPertanianAlat Pembibitan', 'PertanianSeeder'),
('Industri', 'Site Plan', 'Lokasi Proyek', 'Site PlanIndustriLokasi Proyek', 'IndustriSite Plan');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `app_admin`
--
ALTER TABLE `app_admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `queryistilah`
--
ALTER TABLE `queryistilah`
  ADD PRIMARY KEY (`Unique`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `app_admin`
--
ALTER TABLE `app_admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1202181934;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
